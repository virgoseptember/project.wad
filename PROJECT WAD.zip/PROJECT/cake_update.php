<?php
include 'config.php';

$id = $_GET['edit'];

// Fetch existing values from the database
$query = "SELECT * FROM cake WHERE cake_Id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if(isset($_POST['update'])){
    $menu_name = $_POST['nama'];
    $menu_price = $_POST['harga'];
    $menu_qty = $_POST['qty'];

    // Check if a file was uploaded
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $gambar = $_FILES['gambar']['tmp_name'];
        $gambarContent = file_get_contents($gambar); // Read the file content
        
        // Prepare the SQL statement
        $stmt = $conn->prepare("UPDATE cake SET name=?, price=?, qty=?, image=? WHERE cake_id=?");
        
        // Bind parameters and execute the statement
        $stmt->bind_param("siisi", $menu_name, $menu_price, $menu_qty, $gambarContent, $id);
        $stmt->execute();
        
        // Check if the update was successful
        if($stmt->affected_rows > 0){
            $pesan = "Menu berhasil diperbarui";
        } else {
            $pesan2 = "Gagal memperbarui menu";
        }

        // Close statement
        $stmt->close();
    } else {
        // Handle case where no file was uploaded or upload error occurred
        $pesan = "Harap unggah gambar";
    }
}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin.css">
    <script src="https://kit.fontawesome.com/57fc687294.js" crossorigin="anonymous"></script>
    <title>Update Cake</title>
</head>
<body>
<?php
if(isset($pesan)){
    echo '<span class="pesan">'.$pesan.'</span>';
}
if(isset($pesan2)){
    echo '<span class="pesan2">'.$pesan2.'</span>';
}
?>
<div class="kontainer">
    <div class="admin-form-kontainer tengah">
        <form action="<?php echo $_SERVER['PHP_SELF'] . "?edit=" . $id; ?>" method="post" enctype="multipart/form-data">
            <h3>Update Kue</h3>
            <input type="text" placeholder="nama product" name="nama" class="nma" value="<?php echo $row['name']; ?>">
            <input type="number" placeholder="harga product" name="harga" class="nma" value="<?php echo $row['price']; ?>">
            <input type="number" placeholder="jumlah product" name="qty" class="nma" value="<?php echo $row['qty']; ?>">
            <input type="file" name="gambar" class="nma" accept=".png,.jpg,.jpeg">
            <input type="submit" class="btn" name="update" value="Update Menu">
            <a href="cake_page.php" class="btn">Kembali</a>
        </form>
    </div>
</div>
</body>
</html>