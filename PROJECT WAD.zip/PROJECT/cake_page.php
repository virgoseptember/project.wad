<?php
include 'config.php';

if(isset($_POST['tambah'])){
    $menu_name = $_POST['nama'];
    $menu_price = $_POST['harga'];
    $menu_qty = $_POST['qty'];


    // Check if a file was uploaded
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $gambar = $_FILES['gambar']['tmp_name'];
        $gambarContent = file_get_contents($gambar); // Read the file content
        
        // Prepare the SQL statement
        $stmt = $conn->prepare("INSERT INTO cake (name, qty, price, image) VALUES (?, ?, ?, ?)");
        
        // Bind parameters and execute the statement
        $stmt->bind_param("siis", $menu_name, $menu_qty, $menu_price, $gambarContent);
        $stmt->execute();
        
        // Check if the insertion was successful
        if($stmt->affected_rows > 0){
            $pesan = "Menu baru telah ditambahkan";
        } else {
            $pesan2 = "Gagal menambahkan menu";
        }

        // Close statement
        $stmt->close();
    } else {
        // Handle case where no file was uploaded or upload error occurred
        $pesan = "Harap unggah gambar";
    }
};
    if(isset($_GET['delete'])){
        $id =$_GET['delete'];
        mysqli_query($conn,"DELETE FROM cake where cake_Id = $id");
        header('location:cake_page.php');
    }
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin.css">
    <script src="https://kit.fontawesome.com/57fc687294.js" crossorigin="anonymous"></script>
    <title>Document</title>
    <style>
        /* Add your CSS styles for the navbar here */
        .navbar {
            display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.4rem 37%;
    background-color: rgba(1, 1, 1,0.8);
    border-bottom: 1px solid #513c28;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 9999;
    height: 8vh;
    
        }

        .navbar a {
            color: #fff;
    display: inline-block;
    font-size: 1.3rem;
    margin: 0 1rem;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
            padding: 2rem;
        }
    </style>
</head>
<body>


    <?php
    if(isset($pesan)){
        echo '<span class="pesan">'.$pesan.'</span>';
    }
    if(isset($pesan2)){
        echo '<span class="pesan2">'.$pesan2.'</span>';
    }
    ?>
       <!-- Navbar -->
       <div class="navbar">
        <a href="food_page.php">Makanan</a>
        <a href="cake_page.php">Kue</a>
        <a href="drink_page.php">Minuman</a>
        <a href="cosmetic_page.php">Cosmetik</a>
    </div>

    <div class="kontainer">
        <div class="admin-form-kontainer">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
                <h3>Tambah Kue</h3>
                <input type="text" placeholder="nama product" name="nama" class="nma">
                <input type="number" placeholder="harga product" name="harga" class="nma">
                <input type="number" placeholder="jumlah product" name="qty" class="nma">
                <input type="file" name="gambar" class="nma" accept=".png,.jpg,.jpeg">
                <input type="submit" class="btn" name="tambah" value="Tambah Menu">
            </form>
        </div>
        <?php
            $select = mysqli_query($conn,"SELECT * FROM cake");
        ?>
        <div class="display-menu">
            <table class="display-table" style = "border:1px solid;">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Nama</th>
                        <th>Harga</th>
                        <th>Stok</th>
                       
                        <th colspan="2">Tombol</th>
                    </tr>
                </thead>
                <?php
                while($row = mysqli_fetch_assoc($select)){
                ?>
                    <tr>
                    <td><img src='data:image/jpeg;base64,<?php echo base64_encode($row['image']); ?>' alt='Menu Image'></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['price']; ?></td>
            <td><?php echo $row['qty']; ?></td>
            <td >
                    <a href="cake_update.php?edit=<?php echo $row['cake_Id']; ?> " class="btn"><i class="fa-solid fa-pen-to-square"></i>Edit</a>
                    <a href="cake_page.php?delete=<?php echo $row['cake_Id']; ?> " class="btn2"><i class="fa-solid fa-trash-can"></i>Delete</a>
            </td>
                    </tr>
                <?php };   ?>
            </table> 
        </div>
    </div>
</body>
</html>