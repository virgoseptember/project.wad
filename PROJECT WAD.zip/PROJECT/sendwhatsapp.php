<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $nama = $_POST["nama"];
    $email = $_POST["email"];
    $no_hp = $_POST["no_hp"];

    // Compose the WhatsApp message
    $message = "Halo, saya ingin menanyakan sesuatu.\n";
    $message .= "Nama: " . $nama . "\n";
    $message .= "Email: " . $email . "\n";
    $message .= "No HP: " . $no_hp;

    // Encode the message for use in a URL
    $encoded_message = urlencode($message);

    // Construct the WhatsApp URL
    $whatsapp_url = "https://wa.me/6285280448972?text=" . $encoded_message;

    // Redirect the user to WhatsApp
    header("Location: " . $whatsapp_url);
    exit;
} else {
    // If the form is not submitted, redirect the user to the homepage or another appropriate page
    header("Location: index.php");
    exit;
}
?>