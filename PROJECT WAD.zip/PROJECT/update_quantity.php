<?php
// Check if the request is a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract item ID and new quantity from the POST data
    $itemId = $_POST['item_id'];
    $newQty = $_POST['new_qty'];

    // Your database connection code here
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "menu";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Update the quantity of the item in the database
    $sql = "UPDATE cart SET c_qty = $newQty WHERE CID = $itemId";
    if ($conn->query($sql) === TRUE) {
        // Fetch the new total price for the item
        $sql = "SELECT c_price FROM cart WHERE CID = $itemId";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $newTotalPrice = $row['c_price'] * $newQty;
            // Return the new total price as a response
            echo $newTotalPrice;
        }
    } else {
        // Error updating quantity
        echo "Error updating quantity";
    }

    // Close the database connection
    $conn->close();
}
?>
