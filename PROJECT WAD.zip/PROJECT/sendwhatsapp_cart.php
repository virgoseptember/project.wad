<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "menu";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch cart data from the database
$sql = "SELECT * FROM cart";
$result = $conn->query($sql);

// Initialize variables to store cart items and total price
$cart_items = array();
$total_price = 0;

if ($result->num_rows > 0) {
    // Loop through each cart item and store in $cart_items array
    while ($row = $result->fetch_assoc()) {
        $cart_items[] = array(
            "name" => $row['c_name'],
            "quantity" => $row['c_qty'],
            "price" => $row['c_price']
        );

        // Calculate total price
        $total_price += ($row['c_price'] * $row['c_qty']);
    }
}

// Close the database connection
$conn->close();

// Compose the WhatsApp message
$message = "Halo, saya ingin memesan barang-barang berikut:\n";
foreach ($cart_items as $item) {
    $message .= "Nama Barang: " . $item['name'] . ", ";
    $message .= "Qty: " . $item['quantity'] . ", ";
    $message .= "Harga: IDR " . $item['price'] . "\n";
}
$message .= "\nTotal Harga: IDR " . $total_price;

// Encode the message for use in a URL
$encoded_message = urlencode($message);

// Construct the WhatsApp URL
$whatsapp_number = "6285280448972"; // Replace with your actual WhatsApp number
$whatsapp_url = "https://wa.me/{$whatsapp_number}?text={$encoded_message}";

// Redirect the user to WhatsApp
header("Location: {$whatsapp_url}");
exit;
?>
