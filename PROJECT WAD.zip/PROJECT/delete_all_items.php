<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "menu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Truncate (remove all data from) the cart table
$sql = "TRUNCATE TABLE cart";
if ($conn->query($sql) === TRUE) {
    echo "All items deleted successfully";
} else {
    echo "Error deleting items: " . $conn->error;
}

// Close the database connection
$conn->close();
?>
