<?php
// Start output buffering
ob_start();

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "menu";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the selected category from the AJAX request
$category = isset($_GET['category']) ? $_GET['category'] : 'all';

// Fetch data from the corresponding table(s) based on the selected category or all categories
if ($category === 'all') {
    // Fetch data from all tables
    $sql = "SELECT * FROM food UNION SELECT * FROM drink UNION SELECT * FROM cake UNION SELECT * FROM cosmetic";
} else {
    // Fetch data from the specified category table
    // Adjust the SQL query based on your database schema
    $sql = "SELECT * FROM $category";
}

// Execute the SQL query
$result = $conn->query($sql);

// Check if the query was successful
if ($result) {
    // Process the query result
    // Display or process fetched data as needed

    // Display fetched data
   // Display fetched data
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<form method='POST' action='" . $_SERVER['PHP_SELF'] . "' enctype='multipart/form-data'>"; // Start form
        echo "<div class='menu-item'>";
        echo "<img src='data:image/jpeg;base64," . base64_encode($row['image']) . "' alt='Menu Image'>";
        echo "<h3>Nama:  " . $row['name'] . "</h3>";
        echo "<p>Price: IDR" . $row['price'] . "</p>";
        echo "<input type='hidden' name='mname' value='" . $row['name'] . "'>"; // Hidden input for name
        echo "<input type='hidden' name='mprice' value='" . $row['price'] . "'>"; // Hidden input for price
        echo "<input type='hidden' name='mimage' value='" . base64_encode($row['image']) . "'>"; // Hidden input for image
        echo "<input type='submit' value='Add to Cart' class='input' name='add-to-cart'>"; // Submit button
        echo "</div>";
        echo "</form>"; // End form
    }
    } else {
        echo "No menu items found for this category";
    }
} else {
    // Handle the case where the query fails
    echo "Error executing query: " . $conn->error;
}

if (isset($_POST["add-to-cart"])) {
    // Extract form data
    $prod_name = $_POST["mname"];
    $prod_price = $_POST["mprice"];
    $prod_image = $_POST["mimage"];
    $prd_qty = 1;

    // Check if the product already exists in the cart
    $check_existing = mysqli_query($conn, "SELECT * FROM cart WHERE c_name = '$prod_name'");
    
    if (mysqli_num_rows($check_existing) > 0) {
        // Product already exists in the cart, redirect to index.php
        header("Location: index.php");
        exit();
    } else {
        // Product doesn't exist in the cart, insert it
        $insert = mysqli_query($conn, "INSERT INTO cart (c_name, c_price, c_image, c_qty) VALUES ('$prod_name','$prod_price','$prod_image','$prd_qty')");
        if ($insert) {
            // Display message and redirect to index.php
            echo "<div style='background-color: #f44336; color: white; padding: 10px;'>Data has been added to cart table</div>";
            header("Location: index.php");
            exit(); // Ensure script execution stops after redirection
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}

// Close the database connection
$conn->close();

// Flush the output buffer and send the buffered output to the browser
ob_end_flush();
?>
