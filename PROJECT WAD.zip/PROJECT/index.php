
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/your-fontawesome-kit-id.js" crossorigin="anonymous"></script>>
    <link rel="stylesheet" href="index.css">
    <!--alpine js-->
    <script src="https://kit.fontawesome.com/57fc687294.js" crossorigin="anonymous"></script>
    <title>Document</title>
   
</head>
<body>
    <!-- navbar -->
    <nav class="nav">
        <a href="#" class="logo">Dean<span>Store</span></a> 
        <div class="menu ">
        <a href="#home">Home</a>
        <a href="#tentang">Tentang Kami</a>
        <a href="#menu">Menu</a>
        <a href="#kontak">Kontak</a>

        </div>
        <div class="icon">
            <a href="#" id="search-btn"><i class="fa-solid fa-magnifying-glass"></i></a>
            <a href="#" id="keranjang"><i class="fa-solid fa-cart-shopping"></i></a>
            <a href="#" id="hamburger"><i class="fa-solid fa-bars"></i></a>
        </div>
        <!--search engine -->
       <form action="#" method="GET" class="search-engine" id="search-form">
            <input type="search" name="query" id="search" placeholder="Cari...">
            <button type="submit" id="search-submit"><i class="fa-solid fa-magnifying-glass "></i></button>
        </form>
        <!--shop cart-->
        <div class="shopcart">
        <?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "menu";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for quantity update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['qty']) && isset($_POST['item_id'])) {
    // Validate quantity
    $newQty = intval($_POST['qty']);
    if ($newQty <= 0) {
        // Quantity is not positive or is not an integer
        // Handle the error or provide feedback to the user
        echo "Quantity must be a positive integer.";
        exit; // Stop further execution
    }

    $itemId = $_POST['item_id'];

    // Fetch the row data from the cart table
    $sql_fetch_row = "SELECT * FROM cart WHERE CID = $itemId";
    $result_row = $conn->query($sql_fetch_row);

    if ($result_row->num_rows > 0) {
        $row = $result_row->fetch_assoc();
        // Perform the database update
        $sql_update = "UPDATE cart SET c_qty = $newQty WHERE CID = $itemId";
        if ($conn->query($sql_update) === TRUE) {
            // Quantity updated successfully
            // Fetch the new total price for the item
            $newTotalPrice = $row['c_price'] * $newQty;
            // Return the new total price as a response
            echo $newTotalPrice;
        } else {
            // Error updating quantity
            echo "Error updating quantity";
        }
    } else {
        // Item not found in the cart
        echo "Item not found in the cart";
    }
}

// Handle form submission for deleting all items
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_all'])) {
    // Delete all items from the cart table
    $sql_delete_all = "TRUNCATE TABLE cart";
    if ($conn->query($sql_delete_all) === TRUE) {
        echo "All items deleted successfully";
    } else {
        echo "Error deleting items: " . $conn->error;
    }
}

// Fetch data from the cart table
$sql = "SELECT * FROM cart";
$result = $conn->query($sql);

// Check if any cart items exist
if ($result->num_rows > 0) {
 
    echo '<h2>Shopping Cart</h2>';
    echo '<div class="cartitem">';
    // Loop through each cart item and display it
    // Initialize total price variable
    $totalPrice = 0;

    // Inside the while loop where you display cart items
    while($row = $result->fetch_assoc()) {
        echo '<form method="post" class="cartitem">'; // Form for each cart item
        // Display image if available
        if (!empty($row['c_image'])) {
            echo '<img src="data:image/jpeg;base64,' . $row['c_image'] . '" alt="Cart Item Image">';
        } else {
            echo '<img src="default-image.jpg" alt="Default Image">';
        }
        echo '<div class="item-details">';
        echo '<h3>' . $row['c_name'] . '</h3>';
        echo '<p>';
        echo '<input type="number" name="qty" id="qty-' . $row['CID'] . '" value="' . $row['c_qty'] . '" min="1" onchange="this.form.submit()">'; // Quantity input
        echo '<input type="hidden" name="item_id" value="' . $row['CID'] . '">'; // Hidden input for item ID
        echo '</p>';
        echo '<div class="price">IDR ' . ($row['c_price'] * $row['c_qty']) . '</div>'; // Price display
        echo '</div>'; // Close item-details
        echo '</form>'; // Close form for cart item

        // Add the price of the current item to the total
        $totalPrice += ($row['c_price'] * $row['c_qty']);
    }
    // Display the total price
    echo '<h3>Total Price: IDR ' . $totalPrice . '</h3>';
    echo '</div>'; // Close cartitem div

    // Display the "Delete All" button below the total price
    echo '<form method="post" class="delete-all-form">';
    echo '<button type="submit" name="delete_all" class="delete-all-btn">Delete All</button>';
    echo '</form>';
    
    // Add a "Checkout" button


    // Add a form for user data input
    echo '<form method="post" id="user-data-form" class="user-data" action="sendwhatsapp_cart.php">
    <div class="user-data">';
    echo '<div class="user-data">';
    echo '<input type="text" id="name" name="name" required placeholder="Nama">';
    echo '<input type="text" id="phone" name="phone" required  required placeholder="No Hp">';
    echo '<textarea id="address" name="address" required>Alamat</textarea  required ">';
    echo '</div>';
    echo '<button type="submit" name="submit" class="submit-btn">Submit</button>';
    echo '</form>';
} else {
    echo '<h2>Your cart is empty!</h2>';
}


// Close the database connection
$conn->close();
?>
</div>

        </div>
    </nav>
    <!--landing-->
    <section class="landing" id="home">
        <div class="konten">
            <h1>Selamat Datang di Dean<span>Store</span></h1>
            <p>Toko Online Untuk Membeli Makanan, Minuman, Kue, dan Kosmetik</p>
            <a href="#menu" class='cta'>Beli Sekarang</a>
        </div>
    </section>
    <!--tentang-->
    <section class="about" id="tentang">
    <h2>Tentang<span>Kami</span></h2>
    <div class="baris">
        <div class="tentangImg">
            <img src="src/tentang-kami.jpg" >
        </div>
        <div class="konten">
            <h3>Kenapa memilih kami?</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam, delectus suscipit iure
                 praesentium nobis ipsum.</p>
            <p>Karna Dean Store </p>
        </div>
    </div>
    </section>
    <section class="menu2" id="menu">
    <h2>Menu<span>Kami</span></h2>
   <!-- Add buttons for each category -->
  <!-- Add buttons for each category -->

  <button onclick="filterMenu('all')" id="btn-all">Show All</button>
        <button onclick="filterMenu('food')" id="btn-food">Makanan</button>
        <button onclick="filterMenu('drink')" id="btn-drink">Minuman</button>
        <button onclick="filterMenu('cake')" id="btn-cake">Kue</button>
        <button onclick="filterMenu('cosmetic')" id="btn-cosmetic">Kosmetik</button>
    

<!-- Container to display menu items -->
<div class="menuu" id="menu-container"></div>




    </section>
<!-- kontak-->
    <section class="kontak" id="kontak">
    <h2>Kontak <span>Kami</span></h2>
    <p>Ada Hal yang ingin ditanyakan? anda bisa menghubungi saya lewat form ataupun WhatsApp.
    </p>
    <div class="row">
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1983.4297503325954!2d106.226998!3d-6.149564!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e41f55df90cf5db%3A0xfe32280660937296!2sGriya%20Pepes%20Mbak%20Titik!5e0!3m2!1sid!2sid!4v1713463459550!5m2!1sid!2sid"  allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="maps"></iframe>
    <form action="sendwhatsapp.php" method="POST" id="contact-form">
    <div class="grup">
        <i class="fa-regular fa-user"></i>
        <input type="text" name="nama" id="nama" placeholder="Nama">
    </div>
    <div class="grup">
        <i class="fa-regular fa-envelope"></i>
        <input type="email" name="email" id="email" placeholder="Email">
    </div>
    <div class="grup">
        <i class="fa-solid fa-phone"></i>
        <input type="text" name="no_hp" id="no_hp" placeholder="No Hp">
    </div>
    <button type="submit" class="btn" onclick="sendWhatsApp()">Kirim Pesan Sekarang</button>
</form>
    </div>
    </section>
    <!--footer-->
        <footer >
            <div class="sosmed">
                <a href=""><i class="fa-brands fa-instagram"></i></a>
                <a href=""><i class="fa-brands fa-facebook"></i></a>
               
            </div>
            <div class="link">
                <a href="#home">Home</a>
                <a href="#tentang">Tentang Kami</a>
                <a href="#menu">Menu</a>
                <a href="#kontak">Kontak</a>
            </div>
            <div class="kredit">
                <p>Di buat oleh Dean Store. | &copy: 2024.</p>
            </div>
        </footer>
    <!--js-->
    <script>
        // Toggle search form visibility
        const searchForm = document.querySelector('.search-engine');
        document.querySelector('#search-btn').onclick = (e) => {
            searchForm.classList.toggle('active');
            searchForm.querySelector('input').focus(); // Focus on the search input
            e.preventDefault(); // Prevent default behavior of anchor element
        };

 // Function to perform search
function performSearch() {
    // Get the search query
    const searchQuery = document.getElementById('search').value.trim().toLowerCase();

    // Get all menu items
    const menuItems = document.querySelectorAll('.menu-item');

    // Loop through each menu item and show/hide based on search query
    let firstMatchedItem = null;
    menuItems.forEach(item => {
        const itemName = item.querySelector('h3').innerText.toLowerCase();
        if (itemName.includes(searchQuery)) {
            item.style.display = 'block'; // Show the item if it matches the search query
            if (!firstMatchedItem) {
                firstMatchedItem = item; // Set the first matched item
            }
        } else {
            item.style.display = 'none'; // Hide the item if it doesn't match the search query
        }
    });

    // Scroll to the first matched item if found within the menu section
    if (firstMatchedItem) {
        const menuSection = document.getElementById('menu');
        firstMatchedItem.scrollIntoView({ behavior: 'smooth', block: 'start', container: menuSection });
    }
}

// Add event listener to the search input field to trigger searchMenu() when Enter key is pressed
document.getElementById('search').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault(); // Prevent the default action of the Enter key
        performSearch(); // Perform the search
    }
});

// Add event listener to the search submit button
document.getElementById('search-submit').addEventListener('click', function(e) {
    e.preventDefault(); // Prevent the default action of the form submit
    performSearch(); // Perform the search
});
        // Add event listener to the search submit button
        document.getElementById('search-submit').addEventListener('click', performSearch);

        var prevSelectedBtnId = ""; // Variable to store the ID of the previously selected button

        // Function to filter menu items based on category
        function filterMenu(category) {
            // Make an AJAX request to fetch data based on the selected category
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Displaying fetched data in the menu container
                    document.getElementById("menu-container").innerHTML = this.responseText;
                }
            };

            // Pass the selected category
            xhttp.open("GET", "databse.php?category=" + category, true);
            xhttp.send();

            // Change background color of selected button
            var selectedBtn = document.getElementById("btn-" + category);
            if (prevSelectedBtnId !== "") {
                var prevSelectedBtn = document.getElementById(prevSelectedBtnId);
                prevSelectedBtn.style.backgroundColor = "white"; // Reset previous button color
            }
            selectedBtn.style.backgroundColor = "lightblue"; // Set selected button color
            prevSelectedBtnId = selectedBtn.id; // Update previous selected button ID
        }

        // Call filterMenu('all') when the page is loaded
        window.onload = function() {
            filterMenu('all');
        };


    </script>
        <script>
        //togle//
        const navbar = document.querySelector('.menu');
        document.querySelector('#hamburger').onclick = (e)=> {
            navbar.classList.toggle('active'); 
            e.preventDefault();
        };

        //klik luar sidebar//
        const hmg = document.querySelector('#hamburger');
        const sb  = document.querySelector('#search-btn');
        const shp = document.querySelector('#keranjang');
        const cart= document.querySelector('.shopcart');
        document.addEventListener('click',function(e){
            if(!hmg.contains(e.target) && !navbar.contains(e.target)){
                navbar.classList.remove('active');
            }
            if(!sb.contains(e.target) && !searchForm.contains(e.target)){
                searchForm.classList.remove('active');
            }
            if(!shp.contains(e.target)&& !cart.contains(e.target)){
                cart.classList.remove('active');
            }
            document.querySelector('#keranjang').onclick = (e)=> {
                cart.classList.toggle('active');
                e.preventDefault();
            };
          
        });
    </script>
    
</body>
</html>