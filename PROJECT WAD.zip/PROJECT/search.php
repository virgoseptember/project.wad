<?php
// Check if the form is submitted
if (isset($_GET['submit'])) {
    // Get the search query from the URL parameter
    $searchQuery = $_GET['query'];

    // Perform database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "menu";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to search for menu items
    $sql = "SELECT * FROM menu WHERE item_name LIKE '%$searchQuery%'";
    $result = $conn->query($sql);

    // Check if any results were found
    if ($result->num_rows > 0) {
        // Output data of each row
        echo "<h2>Search Results for: $searchQuery</h2>";
        echo "<div class='menu-container'>";
        while ($row = $result->fetch_assoc()) {
            echo "<div class='menu-item'>";
            echo "<img src='data:image/jpeg;base64," . base64_encode($row['image']) . "' alt='Menu Image'>";
            echo "<h3>Nama:  " . $row['name'] . "</h3>";
            echo "<p>Stok: " . $row['qty'] . "</p>";
            echo "<p>Expire: " . $row['exp'] . "</p>";
            echo "<p>Price: IDR" . $row['price'] . "</p>";
            echo "<button><i class='fa-solid fa-plus fa'></i></button>"; 
            // You can add more details as needed
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p>No results found for: $searchQuery</p>";
    }

    // Close database connection
    $conn->close();
}
?>
